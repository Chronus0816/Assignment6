function addTask() {
    const newTask = document.getElementById("newTask");
    if (newTask.value.trim() !== '') {
        const li = document.createElement("li");
        li.textContent = newTask.value;
        document.getElementById("taskList").appendChild(li);
        newTask.value = ''; // Clear the input after adding
    }
}
